﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Trip_Advisor_Web.Models
{
    public class StatusModel
    {
        public int StatusId { get; set; }
        public string StatusName { get; set; }
        public string Description { get; set; }
    }
}